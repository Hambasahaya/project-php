<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard Absensi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .header {
            background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
            color: white;
            padding: 20px;
            text-align: center;
        }

        .user-card {
            background: white;
            padding: 15px;
            border-radius: 10px;
            margin-top: -30px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .btn-icon {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 10px;
            width: 100%;
        }

        .btn-icon i {
            font-size: 24px;
            margin-bottom: 5px;
        }

        .absen-box {
            font-size: 18px;
            font-weight: bold;
            color: white;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }

        .bg-green {
            background-color: #28a745;
        }

        .bg-red {
            background-color: #dc3545;
        }

        .status-box {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
        }

        .data-table {
            background-color: #0d6efd;
            color: white;
            border-radius: 10px;
            padding: 10px;
        }
    </style>
</head>

<body>

    <!-- Header -->
    <div class="header">
        <h3>Winni Code</h3>
        <small>GARUDA TEKNOLOGI</small>
    </div>

    <div class="container mt-3">
        <!-- User Info Card -->
        <div class="user-card">
            <div class="mb-3">
                <p class="mb-0 fw-bold">Selamat Pagi</p>
                <h5>Freedan Rafli Syafiq</h5>
            </div>
            <div class="row text-center">
                <div class="col-3">
                    <button class="btn btn-icon btn-outline-success"><i class="bi bi-camera"></i>Absen</button>
                </div>
                <div class="col-3">
                    <button class="btn btn-icon btn-outline-danger"><i class="bi bi-calendar-x"></i>Cuti</button>
                </div>
                <div class="col-3">
                    <button class="btn btn-icon btn-outline-warning"><i class="bi bi-clock-history"></i>Histori</button>
                </div>
                <div class="col-3">
                    <button class="btn btn-icon btn-outline-secondary"><i class="bi bi-person-circle"></i>Profil</button>
                </div>
            </div>
        </div>

        <!-- Absen Status -->
        <div class="row text-center mt-3">
            <div class="col-md-6 mb-2">
                <div class="absen-box bg-green">Absen Masuk<br>--.--</div>
            </div>
            <div class="col-md-6 mb-2">
                <div class="absen-box bg-red">Absen Pulang<br>--.--</div>
            </div>
        </div>

        <!-- Statistik -->
        <div class="row mt-3">
            <div class="col-12">
                <p><strong>Absensi Bulan <a href="#">Juni 2025</a></strong></p>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="status-box">
                    <i class="bi bi-box-arrow-in-right"></i><br>
                    Hadir<br><strong>0 hari</strong>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="status-box">
                    <i class="bi bi-person"></i><br>
                    Izin<br><strong>0 hari</strong>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="status-box">
                    <i class="bi bi-emoji-frown"></i><br>
                    Sakit<br><strong>0 hari</strong>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="status-box">
                    <i class="bi bi-clock"></i><br>
                    Terlambat<br><strong>0 hari</strong>
                </div>
            </div>
        </div>
        <div class="mt-4">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <strong>1 Minggu Terakhir</strong>
                <i class="bi bi-chevron-down"></i>
            </div>
            <div class="data-table">
                <div class="row fw-bold">
                    <div class="col-4">Tanggal</div>
                    <div class="col-4">Jam Masuk</div>
                    <div class="col-4">Pulang</div>
                </div>
                <div class="row mt-2">
                    <div class="col-4">1 Juni 2025</div>
                    <div class="col-4">07.45</div>
                    <div class="col-4">15.00</div>
                </div>
            </div>
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" />
</body>

</html><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/welcome.blade.php ENDPATH**/ ?>