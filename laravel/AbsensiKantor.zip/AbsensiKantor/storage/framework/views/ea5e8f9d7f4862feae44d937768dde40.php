<div class="alert alert-<?php echo e($type ?? 'success'); ?> alert-dismissible fade show" role="alert">
    <?php if($title): ?>
    <h4 class="alert-heading"><?php echo e($title); ?></h4>
    <?php endif; ?>

    <p><?php echo e($slot); ?></p>

    <?php if($footer): ?>
    <hr>
    <p class="mb-0"><strong><?php echo e($footer); ?></strong></p>
    <?php endif; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/components/showalert.blade.php ENDPATH**/ ?>