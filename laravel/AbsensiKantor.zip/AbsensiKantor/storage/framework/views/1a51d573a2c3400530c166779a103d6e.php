

<?php $__env->startSection('content'); ?>
<?php if(session("pengajuans_success")): ?>
<?php if (isset($component)) { $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $attributes; } ?>
<?php $component = App\View\Components\Showalert::resolve(['type' => 'success','title' => 'Well done!','footer' => ''.e(session('pengajuans_success')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('showalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Showalert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $attributes = $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $component = $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php endif; ?>
<?php if(session("pengajuans_fail")): ?>
<?php if (isset($component)) { $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $attributes; } ?>
<?php $component = App\View\Components\Showalert::resolve(['type' => 'danger','title' => 'Well fail!','footer' => ''.e(session('pengajuans_fail')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('showalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Showalert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $attributes = $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $component = $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php endif; ?>

<?php if(session("berhasil_register")): ?>
<?php if (isset($component)) { $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $attributes; } ?>
<?php $component = App\View\Components\Showalert::resolve(['type' => 'success','title' => 'Well done!','footer' => ''.e(session('berhasil_register')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('showalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Showalert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $attributes = $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $component = $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php endif; ?>

<?php if(session("gagal_register")): ?>
<?php if (isset($component)) { $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $attributes; } ?>
<?php $component = App\View\Components\Showalert::resolve(['type' => 'danger','title' => 'Well fails!','footer' => ''.e(session('gagal_register')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('showalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Showalert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $attributes = $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $component = $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e = $attributes; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $attributes = $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>

<div class="container mt-3">
    <?php if (isset($component)) { $__componentOriginal7c77e2b2da0e123bda5bfb8059d757c9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c77e2b2da0e123bda5bfb8059d757c9 = $attributes; } ?>
<?php $component = App\View\Components\Headerinfo::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('headerinfo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Headerinfo::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c77e2b2da0e123bda5bfb8059d757c9)): ?>
<?php $attributes = $__attributesOriginal7c77e2b2da0e123bda5bfb8059d757c9; ?>
<?php unset($__attributesOriginal7c77e2b2da0e123bda5bfb8059d757c9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c77e2b2da0e123bda5bfb8059d757c9)): ?>
<?php $component = $__componentOriginal7c77e2b2da0e123bda5bfb8059d757c9; ?>
<?php unset($__componentOriginal7c77e2b2da0e123bda5bfb8059d757c9); ?>
<?php endif; ?>
</div>
<section id="histori">
    <?php if (isset($component)) { $__componentOriginal74631a4b16323f894b9f26b299ddae85 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74631a4b16323f894b9f26b299ddae85 = $attributes; } ?>
<?php $component = App\View\Components\Tables::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Tables::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74631a4b16323f894b9f26b299ddae85)): ?>
<?php $attributes = $__attributesOriginal74631a4b16323f894b9f26b299ddae85; ?>
<?php unset($__attributesOriginal74631a4b16323f894b9f26b299ddae85); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74631a4b16323f894b9f26b299ddae85)): ?>
<?php $component = $__componentOriginal74631a4b16323f894b9f26b299ddae85; ?>
<?php unset($__componentOriginal74631a4b16323f894b9f26b299ddae85); ?>
<?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.MainLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/Pages/Home.blade.php ENDPATH**/ ?>