<div class="mt-4">
    <div class="d-flex justify-content-between align-items-center mb-2">
        <strong>Daftar Pengajuan</strong>
        <i class="bi bi-chevron-down"></i>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-bordered align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Nama</th>
                    <th>Jenis Pengajuan</th>
                    <th>Tanggal Mulai</th>
                    <th>Tanggal Selesai</th>
                    <th>Status</th>
                    <th>Alasan</th>
                    <th>Bukti</th>

                    <?php if(Auth::user()->level==="HR"): ?>
                    <th>Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pengajuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($data->user->nama); ?></td>
                    <td><?php echo e($data->jenis); ?></td>
                    <td><?php echo e($data->tanggal_mulai); ?></td>
                    <td><?php echo e($data->tanggal_selesai); ?></td>
                    <td><?php echo e(ucfirst($data->status)); ?></td>
                    <td><?php echo e($data->alasan); ?></td>
                    <td>
                        <?php if($data->bukti): ?>
                        <a href="<?php echo e(asset('storage/'.$data->bukti)); ?>" target="_blank">Lihat</a>
                        <?php else: ?>
                        Tidak ada
                        <?php endif; ?>
                    </td>
                    <?php if(Auth::user()->level==="HR"): ?>
                    <td>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-outline-warning"
                                onclick="handlePengajuanAction(<?php echo e($data->id); ?>, 'approve')">Izinkan</button>
                            <button type="button" class="btn btn-outline-danger"
                                onclick="handlePengajuanAction(<?php echo e($data->id); ?>, 'reject')">Tolak</button>
                        </div>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">Tidak ada data pengajuan.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function handlePengajuanAction(id, action) {
        const url = `/pengajuan/${id}/${action}`;
        const token = '<?php echo e(csrf_token()); ?>';

        fetch(url, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': token,
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(res => {
                alert(res.message);
                location.reload();
            })
            .catch(err => {
                alert('Terjadi kesalahan.');
                console.error(err);
            });
    }
</script><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/components/tables-pengajuans.blade.php ENDPATH**/ ?>