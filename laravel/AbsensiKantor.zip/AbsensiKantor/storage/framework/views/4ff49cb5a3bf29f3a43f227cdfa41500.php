 <div class="header">
     <img src="/img/winicode.png" alt="" srcset="" style="width: 12%;">
 </div><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/components/navbar.blade.php ENDPATH**/ ?>