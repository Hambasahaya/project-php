<div class="mt-4">
    <div class="d-flex justify-content-between align-items-center mb-2">
        <strong>1 Minggu Terakhir</strong>
    </div>

    <div class="data-table" id="dataTable">
        <div class="row fw-bold">
            <div class="col-2">Tanggal</div>
            <div class="col-2">Jam Masuk</div>
            <div class="col-2">Pulang</div>
            <div class="col-2">Status</div>
            <div class="col-2">Terlambat</div>
            <div class="col-2">Foto</div>
        </div>

        <?php $__currentLoopData = $dataabsen_week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mt-2">
            <div class="col-2"><?php echo e($data->tanggal); ?></div>
            <div class="col-2"><?php echo e($data->jam_masuk); ?></div>
            <div class="col-2"><?php echo e($data->jam_pulang ?? "belum absen"); ?></div>
            <div class="col-2"><?php echo e($data->status); ?></div>
            <div class="col-2"><?php echo e($data->terlambat == 0 ? "Tidak Terlambat" : "Terlambat"); ?></div>
            <div class="col-2">
                <img
                    src="<?php echo e(asset($data->foto_pulang ? $data->foto_pulang : $data->foto_masuk)); ?>"
                    alt="Foto Absensi"
                    class="rounded-2"
                    style="width: 40%;">
            </div>
        </div>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/components/tables.blade.php ENDPATH**/ ?>