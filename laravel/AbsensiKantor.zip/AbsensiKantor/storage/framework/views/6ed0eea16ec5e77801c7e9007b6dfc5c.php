<?php $__env->startSection('auth'); ?>
<section class="vh-100" style="background-color:white;">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col col-xl-10">
                <div class="card" style="border-radius: 1rem;">
                    <div class="row g-0">
                        <div class="col-md-2 col-lg-12 d-flex align-items-center">
                            <div class="card-body p-4 p-lg-5 text-black">
                                <?php if(session("login_gagal")): ?>
                                <?php if (isset($component)) { $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $attributes; } ?>
<?php $component = App\View\Components\Showalert::resolve(['type' => 'danger','title' => 'Well fail!','footer' => ''.e(session('login_gagal')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('showalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Showalert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $attributes = $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $component = $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
                                <?php endif; ?>
                                <?php if(session("login_berhasil")): ?>
                                <?php if (isset($component)) { $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $attributes; } ?>
<?php $component = App\View\Components\Showalert::resolve(['type' => 'success','title' => 'Well done!','footer' => ''.e(session('login_berhasil')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('showalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Showalert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $attributes = $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $component = $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
                                <?php endif; ?>
                                <?php if(request()->routeIs('auth')): ?>
                                <form action="<?php echo e(route('login')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                                        <span class="h1 fw-bold mb-0">Masuk Akun</span>
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">Email address</label>
                                        <input type="email" id="form2Example17" class="form-control form-control-lg" name="email" required placeholder="Masukan Email..." />
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example27">Password</label>
                                        <input type="password" id="form2Example27" class="form-control form-control-lg" name="password" required placeholder="Masukan Password" />
                                    </div>
                                    <div class="pt-1 mb-4 d-flex w-100 ">
                                        <button data-mdb-button-init data-mdb-ripple-init class="btn btn-lg btn-block w-100" style="background-color: #FF66C4;color:white" type="submit">Login</button>
                                    </div>
                                    <a href="<?php echo e(route('forgetPassword')); ?>" style="color:rgb(0, 34, 255);">Forgot password?</a>
                                    <p class="mb-5 pb-lg-2" style="color:rgb(255, 255, 255);">Don't have an account? <a href="#!"
                                            style="color:rgb(255, 255, 255);">Register here</a></p>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Terms of use.</a>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Privacy policy</a>
                                </form>
                                <?php endif; ?>
                                <?php if(request()->routeIs('forgetPassword')): ?>
                                <form action="<?php echo e(route('verifemail')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                                        <span class="h1 fw-bold mb-0">Lupa password</span>
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">Email address</label>
                                        <input type="email" id="form2Example17" class="form-control form-control-lg" name="email" required placeholder="Masukan Email..." />
                                    </div>
                                    <div class="pt-1 mb-4 d-flex w-100 ">
                                        <button data-mdb-button-init data-mdb-ripple-init class="btn btn-lg btn-block w-100" style="background-color: #FF66C4;color:white" type="submit">Cek Email!</button>
                                    </div>
                                    <a href="" style="color:rgb(255, 255, 255);">Forgot password?</a>
                                    <p class="mb-5 pb-lg-2" style="color:rgb(255, 255, 255);">Don't have an account? <a href="#!"
                                            style="color:rgb(255, 255, 255);">Register here</a></p>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Terms of use.</a>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Privacy policy</a>
                                </form>
                                <?php endif; ?>
                                <?php if(request()->routeIs('verif')): ?>
                                <form action="<?php echo e(route('verif_token')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                                        <span class="h1 fw-bold mb-0">Masukan Kode untuk reset Password</span>
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">token</label>
                                        <input type="text" id="form2Example17" class="form-control form-control-lg" name="token" required placeholder="Masukan Token" />
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">New Password</label>
                                        <input type="password" id="form2Example17" class="form-control form-control-lg" name="password" required placeholder="Masukan Password Baru" />
                                    </div>
                                    <div class="pt-1 mb-4 d-flex w-100 ">
                                        <button data-mdb-button-init data-mdb-ripple-init class="btn btn-lg btn-block w-100" style="background-color: #FF66C4;color:white" type="submit">Verifikasi Token!</button>
                                    </div>
                                    <a href="" style="color:rgb(255, 255, 255);">Forgot password?</a>
                                    <p class="mb-5 pb-lg-2" style="color:rgb(255, 255, 255);">Don't have an account? <a href="#!"
                                            style="color:rgb(255, 255, 255);">Register here</a></p>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Terms of use.</a>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Privacy policy</a>
                                </form>
                                <?php endif; ?>
                                <?php if(request()->routeIs('reset.view')): ?>
                                <form action="<?php echo e(route('login')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                                        <span class="h1 fw-bold mb-0">Masukan Kode untuk reset Password</span>
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">Kode</label>
                                        <input type="number" id="form2Example17" class="form-control form-control-lg" name="email" required placeholder="Masukan Email..." />
                                    </div>
                                    <a href="" style="color:rgb(255, 255, 255);">Forgot password?</a>
                                    <p class="mb-5 pb-lg-2" style="color:rgb(255, 255, 255);">Don't have an account? <a href="#!"
                                            style="color:rgb(255, 255, 255);">Register here</a></p>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Terms of use.</a>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Privacy policy</a>
                                </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.Auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/components/auth.blade.php ENDPATH**/ ?>