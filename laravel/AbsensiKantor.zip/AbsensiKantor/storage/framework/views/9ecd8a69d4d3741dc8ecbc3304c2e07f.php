<div class="modal fade" id="cameraModal" tabindex="-1" aria-labelledby="cameraModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cameraModalLabel">Ambil Foto & Lokasi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <div id="locationInfo" class="mb-3 text-muted">Lokasi belum dideteksi</div>
                <canvas id="canvas" style="display:none;"></canvas>
                <img id="photoPreview" class="img-fluid mt-3 rounded shadow-sm" style="max-height: 350px;" />
                <video id="video" autoplay class="img-fluid rounded mb-3 mx-auto d-block" style="max-height: 300px;"></video>
                <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                    <button class="btn btn-danger" onclick="takePhoto()">Absen Sekarang!</button>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="izinModal" tabindex="-1" aria-labelledby="izinmodal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel"><?php echo e(Auth::user()->level==="HR"?"Tambah Data Pegawai":"Form Pengajuan"); ?></h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(Auth::user()->level === 'HR' ? route('register') : route('addPengajuan')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(Auth::user()->level==="Staff"): ?>
                    <div class="mb-3">
                        <select class="form-select form-select-sm" aria-label="Small select example" name="jenis">
                            <option selected>Pilih Jenis Izin</option>
                            <option value="cuti">Sakit</option>
                            <option value="izin">Cuti</option>
                            <option value="sakit">Izin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Tanggal Mulai</label>
                        <input type="date" class="form-control" id="exampleInputPassword1" name="tanggal_mulai">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Tanggal Selesai</label>
                        <input type="date" class="form-control" id="exampleInputPassword1" name="tanggal_selesai">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Alasan Pengajuan</label>
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="4" name="alasan"></textarea>
                    </div>
                    <div class="mb-3">
                        <div class="input-group mb-3">
                            <input type="file" class="form-control" id="inputGroupFile02" name="bukti">
                            <label class="input-group-text" for="inputGroupFile02 ">Upload Bukti Pendukung</label>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(Auth::user()->level==="HR"): ?>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Nama Staff</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" name="nama">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Email Staff</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" name="email">
                        <div id="emailHelp" class="form-text">Pastikan Email Ini aktif!</div>
                    </div>
                    <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo e(Auth::user()->level==="HR"?"Tambah Data Pegawai":"Ajukan!"); ?></button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="statusmodal" tabindex="-1" aria-labelledby="izinmodal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Daftar Pengajuan</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if (isset($component)) { $__componentOriginal6b058f50ba9f22e68af9bc0057aacb97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b058f50ba9f22e68af9bc0057aacb97 = $attributes; } ?>
<?php $component = App\View\Components\TablesPengajuans::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables-pengajuans'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TablesPengajuans::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b058f50ba9f22e68af9bc0057aacb97)): ?>
<?php $attributes = $__attributesOriginal6b058f50ba9f22e68af9bc0057aacb97; ?>
<?php unset($__attributesOriginal6b058f50ba9f22e68af9bc0057aacb97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b058f50ba9f22e68af9bc0057aacb97)): ?>
<?php $component = $__componentOriginal6b058f50ba9f22e68af9bc0057aacb97; ?>
<?php unset($__componentOriginal6b058f50ba9f22e68af9bc0057aacb97); ?>
<?php endif; ?>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/components/modals.blade.php ENDPATH**/ ?>