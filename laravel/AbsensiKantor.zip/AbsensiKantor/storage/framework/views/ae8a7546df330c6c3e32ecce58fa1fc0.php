<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap @5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .auth-container {
            max-width: 400px;
            width: 100%;
            padding: 2rem;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .otp-input {
            width: 45px;
            text-align: center;
            font-size: 1.2rem;
            margin: 0 5px;
        }

        .form-title {
            font-weight: bold;
            color: #0d6efd;
        }
    </style>
</head>

<body>

    <div class="auth-container" id="pageContainer">
        <!-- Halaman Login -->
        <div id="loginPage">
            <h3 class="form-title mb-4 text-center">Masuk Akun</h3>
            <form>
                <div class="mb-3">
                    <label for="loginEmail" class="form-label">Email</label>
                    <input type="email" class="form-control" id="loginEmail" placeholder="Masukkan email" required />
                </div>
                <div class="mb-3">
                    <label for="loginPassword" class="form-label">Kata Sandi</label>
                    <input type="password" class="form-control" id="loginPassword" placeholder="Masukkan kata sandi" required />
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Masuk</button>
                </div>
                <div class="mt-3 text-center">
                    <a href="#" onclick="showPage('resetPasswordPage')">Lupa Kata Sandi?</a>
                </div>
            </form>
        </div>

        <!-- Halaman Reset Password -->
        <div id="resetPasswordPage" style="display:none;">
            <h3 class="form-title mb-4 text-center">Reset Kata Sandi</h3>
            <p class="text-muted text-center mb-4">Masukkan email Anda untuk menerima kode verifikasi.</p>
            <form onsubmit="event.preventDefault(); showPage('verifyCodePage')">
                <div class="mb-3">
                    <label for="resetEmail" class="form-label">Email</label>
                    <input type="email" class="form-control" id="resetEmail" placeholder="Masukkan email Anda" required />
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Kirim Link Reset</button>
                </div>
                <div class="mt-3 text-center">
                    <a href="#" onclick="showPage('loginPage')">← Kembali ke Login</a>
                </div>
            </form>
        </div>

        <!-- Halaman Verifikasi Kode -->
        <div id="verifyCodePage" style="display:none;">
            <h3 class="form-title mb-4 text-center">Verifikasi Kode</h3>
            <p class="text-muted text-center mb-4">Kami telah mengirimkan kode ke email Anda.</p>
            <form onsubmit="event.preventDefault(); alert('Berhasil! Silakan masukkan kata sandi baru.')">
                <div class="mb-3 d-flex justify-content-center gap-2">
                    <input type="text" maxlength="1" class="form-control otp-input" oninput="moveFocus(this, 0)" id="otp0" />
                    <input type="text" maxlength="1" class="form-control otp-input" oninput="moveFocus(this, 1)" id="otp1" />
                    <input type="text" maxlength="1" class="form-control otp-input" oninput="moveFocus(this, 2)" id="otp2" />
                    <input type="text" maxlength="1" class="form-control otp-input" oninput="moveFocus(this, 3)" id="otp3" />
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success">Verifikasi</button>
                </div>
                <div class="mt-3 text-center">
                    <a href="#" onclick="showPage('resetPasswordPage')">← Kembali</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS (optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap @5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showPage(pageId) {
            const pages = ['loginPage', 'resetPasswordPage', 'verifyCodePage'];
            pages.forEach(id => {
                document.getElementById(id).style.display = id === pageId ? 'block' : 'none';
            });
        }

        function moveFocus(input, index) {
            if (input.value.length === 1 && index < 3) {
                document.getElementById(`otp${index + 1}`).focus();
            }
        }
    </script>
</body>

</html><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/Layouts/mainLayout.blade.php ENDPATH**/ ?>