<div class="user-card">
    <div class="mb-3">
        <p class="mb-0 fw-bold">Selamat datang</p>
        <h5><?php echo e(Auth::user()->nama); ?></h5>
    </div>
    <div class="row d-flex text-center">
        <?php if(Auth::user()->level==="Staff"): ?>
        <div class="col-3">
            <button class="btn btn-icon btn-outline-danger" data-bs-toggle="modal" data-bs-target="#izinModal"><img src="/img/pengajuan.png " class="icon-img" alt="" srcset="">leave application</button>
        </div>
        <?php endif; ?>
        <?php if(Auth::user()->level==="HR"): ?>
        <div class="col-3">
            <button class="btn btn-icon btn-outline-danger" data-bs-toggle="modal" data-bs-target="#izinModal"><img src="/img/pengajuan.png" class="icon-img" alt="" srcset="">Add Pegawai</button>
        </div>
        <?php endif; ?>
        <div class="col-3">
            <button class="btn btn-icon btn-outline-danger" data-bs-toggle="modal" data-bs-target="#statusmodal"><img src="/img/active.png" class="icon-img" alt="" srcset="">Pengajuan Status</button>
        </div>
        <?php if(Auth::user()->level==="Staff"): ?>
        <div class="col-3">
            <a href="#histori" class="btn btn-icon btn-outline-warning"><i class="bi bi-clock-history"></i>Histori</a>
        </div>
        <?php endif; ?>
        <?php if(Auth::user()->level==="HR"): ?>
        <div class="col-3">
            <button class="btn btn-icon btn-outline-warning"><i class="bi bi-people"></i>Total Staff:<?php echo e($StafCount); ?></button>
        </div>
        <?php endif; ?>
        <div class="col-3">
            <a href="<?php echo e(route('logout')); ?>" class="btn btn-icon btn-outline-secondary"><i class="bi bi-box-arrow-right"></i>Keluar</a>
        </div>
    </div>
</div>
<div class="row text-center mt-3">
    <div class="col-md-6 mb-2 ">
        <div class="absen-box bg-green d-flex">
            <h4>Absen Masuk <br>
                <?php if(isset($masuk) && $masuk!=null): ?>
                <?php echo e(\Carbon\Carbon::parse($masuk->tanggal)->setTimeFromTimeString($masuk->jam_masuk)->diffForHumans()); ?>

                <?php else: ?>
                --.--
                <?php endif; ?>
            </h4>
            <?php if($masuk==null): ?>
            <button class="btn btn-primary ms-auto" data-bs-toggle="modal" data-btn="masuk" data-bs-target="#cameraModal"><i class="bi bi-person-square"></i></button>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6 mb-2">
        <div class="absen-box bg-red d-flex">

            <h4>Absen Pulang <br>
                <?php if(isset($pulang) && $pulang!=null): ?>
                <?php echo e(\Carbon\Carbon::parse($pulang->tanggal)->setTimeFromTimeString($masuk->jam_pulang)->diffForHumans()); ?>

                <?php else: ?>
                --.--
                <?php endif; ?>
            </h4>
            <?php if($pulang==null): ?>
            <button class="btn btn-primary ms-auto" data-bs-toggle="modal" data-btn="pulang" data-bs-target="#cameraModal"><i class="bi bi-person-square"></i></button>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="row mt-3">
    <div class="col-12">
        <?php
        $bulan = \Carbon\Carbon::now()->translatedFormat('F');
        $tahun = \Carbon\Carbon::now()->year;
        ?>

        <p><strong>Absensi Bulan <a href="#"><?php echo e($bulan); ?> <?php echo e($tahun); ?></a></strong></p>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="status-box">
            <i class="bi bi-box-arrow-in-right"></i><br>
            Hadir<br><strong><?php echo e($hadir); ?> hari</strong>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="status-box">
            <i class="bi bi-person"></i><br>
            Izin<br><strong><?php echo e($izin); ?> hari</strong>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="status-box">
            <i class="bi bi-emoji-frown"></i><br>
            Sakit<br><strong><?php echo e($sakit); ?> hari</strong>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="status-box">
            <i class="bi bi-clock"></i><br>
            Terlambat<br><strong><?php echo e($terlambat); ?> hari</strong>
        </div>
    </div>
    <form action="<?php echo e(route('rekap.export')); ?>" method="GET" class="d-flex gap-2">
        <select name="range" class="form-select" required>
            <option value="minggu">1 Minggu Terakhir</option>
            <option value="bulan">1 Bulan Terakhir</option>
            <option value="tahun">1 Tahun Terakhir</option>
        </select>
        <?php if(Auth::user()->level==="HR"): ?>
        <select name="user_id" class="form-select">
            <option value="">Semua Pegawai</option>
            <option value="<?php echo e(Auth::user()->id); ?>">Anda Sendiri</option>
        </select>
        <?php endif; ?>
        <?php if(Auth::user()->level==="Staff"): ?>
        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
        <?php endif; ?>

        <button class="btn btn-success" type="submit">Rekap Absen</button>
    </form>
</div>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


<?php if (isset($component)) { $__componentOriginalec44ea46082c33e0f8cbcb5b200babc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalec44ea46082c33e0f8cbcb5b200babc6 = $attributes; } ?>
<?php $component = App\View\Components\Modals::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalec44ea46082c33e0f8cbcb5b200babc6)): ?>
<?php $attributes = $__attributesOriginalec44ea46082c33e0f8cbcb5b200babc6; ?>
<?php unset($__attributesOriginalec44ea46082c33e0f8cbcb5b200babc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec44ea46082c33e0f8cbcb5b200babc6)): ?>
<?php $component = $__componentOriginalec44ea46082c33e0f8cbcb5b200babc6; ?>
<?php unset($__componentOriginalec44ea46082c33e0f8cbcb5b200babc6); ?>
<?php endif; ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\AbsensiKantor\resources\views/components/headerinfo.blade.php ENDPATH**/ ?>