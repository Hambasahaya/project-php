<div class="mt-4">
    <div class="d-flex justify-content-between align-items-center mb-2">
        <strong>Daftar Pengajuan</strong>
        <i class="bi bi-chevron-down"></i>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-bordered align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Nama</th>
                    <th>Jenis Pengajuan</th>
                    <th>Tanggal Mulai</th>
                    <th>Tanggal Selesai</th>
                    <th>Status</th>
                    <th>Alasan</th>
                    <th>Bukti</th>

                    @if(Auth::user()->level==="HR")
                    <th>Aksi</th>
                    @endif
                </tr>
            </thead>
            <tbody>
                @forelse($pengajuans as $data)
                <tr>
                    <td>{{ $data->user->nama }}</td>
                    <td>{{ $data->jenis }}</td>
                    <td>{{ $data->tanggal_mulai }}</td>
                    <td>{{ $data->tanggal_selesai }}</td>
                    <td>{{ ucfirst($data->status) }}</td>
                    <td>{{ $data->alasan }}</td>
                    <td>
                        @if($data->bukti)
                        <a href="{{ asset('storage/'.$data->bukti) }}" target="_blank">Lihat</a>
                        @else
                        Tidak ada
                        @endif
                    </td>
                    @if(Auth::user()->level==="HR")
                    <td>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-outline-warning"
                                onclick="handlePengajuanAction({{ $data->id }}, 'approve')">Izinkan</button>
                            <button type="button" class="btn btn-outline-danger"
                                onclick="handlePengajuanAction({{ $data->id }}, 'reject')">Tolak</button>
                        </div>
                    </td>
                    @endif
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="text-center">Tidak ada data pengajuan.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<script>
    function handlePengajuanAction(id, action) {
        const url = `/pengajuan/${id}/${action}`;
        const token = '{{ csrf_token() }}';

        fetch(url, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': token,
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(res => {
                alert(res.message);
                location.reload();
            })
            .catch(err => {
                alert('Terjadi kesalahan.');
                console.error(err);
            });
    }
</script>