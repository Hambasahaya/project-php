@extends('Layouts.Auth')

@section('auth')
<section class="vh-100" style="background-color:white;">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col col-xl-10">
                <div class="card" style="border-radius: 1rem;">
                    <div class="row g-0">
                        <div class="col-md-2 col-lg-6 d-none d-md-block bg-login">
                        </div>
                        <div class="col-md-2 col-lg-6 d-flex align-items-center">
                            <div class="card-body p-4 p-lg-5 text-black">
                                @if(session("login_gagal"))
                                <x-showalert
                                    type="danger"
                                    title="Well fail!"
                                    footer="{{session('login_gagal')}}">
                                </x-showalert>
                                @endif
                                @if(session("login_berhasil"))
                                <x-showalert
                                    type="success"
                                    title="Well done!"
                                    footer="{{session('login_berhasil')}}">
                                </x-showalert>
                                @endif
                                @if(request()->routeIs('auth'))
                                <form action="{{route('login')}}" method="post">
                                    @csrf
                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                                        <span class="h1 fw-bold mb-0">Masuk Akun</span>
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">Email address</label>
                                        <input type="email" id="form2Example17" class="form-control form-control-lg" name="email" required placeholder="Masukan Email..." />
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example27">Password</label>
                                        <input type="password" id="form2Example27" class="form-control form-control-lg" name="password" required placeholder="Masukan Password" />
                                    </div>
                                    <div class="pt-1 mb-4 d-flex w-100 ">
                                        <button data-mdb-button-init data-mdb-ripple-init class="btn btn-lg btn-block w-100" style="background-color: #FF66C4;color:white" type="submit">Login</button>
                                    </div>
                                    <a href="{{route('forgetPassword')}}" style="color:rgb(0, 34, 255);">Forgot password?</a>
                                    <p class="mb-5 pb-lg-2" style="color:rgb(255, 255, 255);">Don't have an account? <a href="#!"
                                            style="color:rgb(255, 255, 255);">Register here</a></p>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Terms of use.</a>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Privacy policy</a>
                                </form>
                                @endif
                                @if(request()->routeIs('forgetPassword'))
                                <form action="{{route('verifemail')}}" method="post">
                                    @csrf
                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                                        <span class="h1 fw-bold mb-0">Lupa password</span>
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">Email address</label>
                                        <input type="email" id="form2Example17" class="form-control form-control-lg" name="email" required placeholder="Masukan Email..." />
                                    </div>
                                    <div class="pt-1 mb-4 d-flex w-100 ">
                                        <button data-mdb-button-init data-mdb-ripple-init class="btn btn-lg btn-block w-100" style="background-color: #FF66C4;color:white" type="submit">Cek Email!</button>
                                    </div>
                                    <a href="" style="color:rgb(255, 255, 255);">Forgot password?</a>
                                    <p class="mb-5 pb-lg-2" style="color:rgb(255, 255, 255);">Don't have an account? <a href="#!"
                                            style="color:rgb(255, 255, 255);">Register here</a></p>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Terms of use.</a>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Privacy policy</a>
                                </form>
                                @endif
                                @if(request()->routeIs('verif'))
                                <form action="{{route('verif_token')}}" method="post">
                                    @csrf
                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                                        <span class="h1 fw-bold mb-0">Masukan Kode untuk reset Password</span>
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">token</label>
                                        <input type="text" id="form2Example17" class="form-control form-control-lg" name="token" required placeholder="Masukan Token" />
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">New Password</label>
                                        <input type="password" id="form2Example17" class="form-control form-control-lg" name="password" required placeholder="Masukan Password Baru" />
                                    </div>
                                    <div class="pt-1 mb-4 d-flex w-100 ">
                                        <button data-mdb-button-init data-mdb-ripple-init class="btn btn-lg btn-block w-100" style="background-color: #FF66C4;color:white" type="submit">Verifikasi Token!</button>
                                    </div>
                                    <a href="" style="color:rgb(255, 255, 255);">Forgot password?</a>
                                    <p class="mb-5 pb-lg-2" style="color:rgb(255, 255, 255);">Don't have an account? <a href="#!"
                                            style="color:rgb(255, 255, 255);">Register here</a></p>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Terms of use.</a>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Privacy policy</a>
                                </form>
                                @endif
                                @if(request()->routeIs('reset.view'))
                                <form action="{{route('login')}}" method="post">
                                    @csrf
                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                                        <span class="h1 fw-bold mb-0">Masukan Kode untuk reset Password</span>
                                    </div>
                                    <div data-mdb-input-init class="form-outline mb-4">
                                        <label class="form-label" for="form2Example17">Kode</label>
                                        <input type="number" id="form2Example17" class="form-control form-control-lg" name="email" required placeholder="Masukan Email..." />
                                    </div>
                                    <a href="" style="color:rgb(255, 255, 255);">Forgot password?</a>
                                    <p class="mb-5 pb-lg-2" style="color:rgb(255, 255, 255);">Don't have an account? <a href="#!"
                                            style="color:rgb(255, 255, 255);">Register here</a></p>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Terms of use.</a>
                                    <a href="#!" style="color:rgb(255, 255, 255);">Privacy policy</a>
                                </form>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endSection