 <div class="header">
     <img src="/img/winicode.png" alt="" srcset="" style="width: 12%;">
 </div>