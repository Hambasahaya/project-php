<div class="user-card">
    <div class="mb-3">
        <p class="mb-0 fw-bold">Selamat datang</p>
        <h5>{{Auth::user()->nama}}</h5>
    </div>
    <div class="row d-flex text-center">
        @if(Auth::user()->level==="Staff")
        <div class="col-3">
            <button class="btn btn-icon btn-outline-danger" data-bs-toggle="modal" data-bs-target="#izinModal"><img src="/img/pengajuan.png " class="icon-img" alt="" srcset="">leave application</button>
        </div>
        @endif
        @if(Auth::user()->level==="HR")
        <div class="col-3">
            <button class="btn btn-icon btn-outline-danger" data-bs-toggle="modal" data-bs-target="#izinModal"><img src="/img/pengajuan.png" class="icon-img" alt="" srcset="">Add Pegawai</button>
        </div>
        @endif
        <div class="col-3">
            <button class="btn btn-icon btn-outline-danger" data-bs-toggle="modal" data-bs-target="#statusmodal"><img src="/img/active.png" class="icon-img" alt="" srcset="">Pengajuan Status</button>
        </div>
        @if(Auth::user()->level==="Staff")
        <div class="col-3">
            <a href="#histori" class="btn btn-icon btn-outline-warning"><i class="bi bi-clock-history"></i>Histori</a>
        </div>
        @endif
        @if(Auth::user()->level==="HR")
        <div class="col-3">
            <button class="btn btn-icon btn-outline-warning"><i class="bi bi-people"></i>Total Staff:{{$StafCount}}</button>
        </div>
        @endif
        <div class="col-3">
            <a href="{{route('logout')}}" class="btn btn-icon btn-outline-secondary"><i class="bi bi-box-arrow-right"></i>Keluar</a>
        </div>
    </div>
</div>
<div class="row text-center mt-3">
    <div class="col-md-6 mb-2 ">
        <div class="absen-box bg-green d-flex">
            <h4>Absen Masuk <br>
                @if(isset($masuk) && $masuk!=null)
                {{ \Carbon\Carbon::parse($masuk->tanggal)->setTimeFromTimeString($masuk->jam_masuk)->diffForHumans() }}
                @else
                --.--
                @endif
            </h4>
            @if($masuk==null)
            <button class="btn btn-primary ms-auto" data-bs-toggle="modal" data-btn="masuk" data-bs-target="#cameraModal"><i class="bi bi-person-square"></i></button>
            @endif
        </div>
    </div>
    <div class="col-md-6 mb-2">
        <div class="absen-box bg-red d-flex">

            <h4>Absen Pulang <br>
                @if(isset($pulang) && $pulang!=null)
                {{ \Carbon\Carbon::parse($pulang->tanggal)->setTimeFromTimeString($masuk->jam_pulang)->diffForHumans() }}
                @else
                --.--
                @endif
            </h4>
            @if($pulang==null)
            <button class="btn btn-primary ms-auto" data-bs-toggle="modal" data-btn="pulang" data-bs-target="#cameraModal"><i class="bi bi-person-square"></i></button>
            @endif
        </div>
    </div>
</div>
<div class="row mt-3">
    <div class="col-12">
        @php
        $bulan = \Carbon\Carbon::now()->translatedFormat('F');
        $tahun = \Carbon\Carbon::now()->year;
        @endphp

        <p><strong>Absensi Bulan <a href="#">{{ $bulan }} {{ $tahun }}</a></strong></p>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="status-box">
            <i class="bi bi-box-arrow-in-right"></i><br>
            Hadir<br><strong>{{$hadir}} hari</strong>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="status-box">
            <i class="bi bi-person"></i><br>
            Izin<br><strong>{{$izin}} hari</strong>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="status-box">
            <i class="bi bi-emoji-frown"></i><br>
            Sakit<br><strong>{{$sakit}} hari</strong>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="status-box">
            <i class="bi bi-clock"></i><br>
            Terlambat<br><strong>{{$terlambat}} hari</strong>
        </div>
    </div>
    <form action="{{ route('rekap.export') }}" method="GET" class="d-flex gap-2">
        <select name="range" class="form-select" required>
            <option value="minggu">1 Minggu Terakhir</option>
            <option value="bulan">1 Bulan Terakhir</option>
            <option value="tahun">1 Tahun Terakhir</option>
        </select>
        @if(Auth::user()->level==="HR")
        <select name="user_id" class="form-select">
            <option value="">Semua Pegawai</option>
            <option value="{{ Auth::user()->id }}">Anda Sendiri</option>
        </select>
        @endif
        @if(Auth::user()->level==="Staff")
        <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
        @endif

        <button class="btn btn-success" type="submit">Rekap Absen</button>
    </form>
</div>
<meta name="csrf-token" content="{{ csrf_token() }}">


<x-modals></x-modals>