<div class="mt-4">
    <div class="d-flex justify-content-between align-items-center mb-2">
        <strong>1 Minggu Terakhir</strong>
    </div>

    <div class="data-table" id="dataTable">
        <div class="row fw-bold">
            <div class="col-2">Tanggal</div>
            <div class="col-2">Jam Masuk</div>
            <div class="col-2">Pulang</div>
            <div class="col-2">Status</div>
            <div class="col-2">Terlambat</div>
            <div class="col-2">Foto</div>
        </div>

        @foreach($dataabsen_week as $data)
        <div class="row mt-2">
            <div class="col-2">{{ $data->tanggal }}</div>
            <div class="col-2">{{ $data->jam_masuk }}</div>
            <div class="col-2">{{ $data->jam_pulang ?? "belum absen" }}</div>
            <div class="col-2">{{ $data->status }}</div>
            <div class="col-2">{{ $data->terlambat == 0 ? "Tidak Terlambat" : "Terlambat" }}</div>
            <div class="col-2">
                <img
                    src="{{ asset($data->foto_pulang ? $data->foto_pulang : $data->foto_masuk) }}"
                    alt="Foto Absensi"
                    class="rounded-2"
                    style="width: 40%;">
            </div>
        </div>
        <hr>
        @endforeach
    </div>
</div>