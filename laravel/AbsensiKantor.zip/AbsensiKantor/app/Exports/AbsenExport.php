<?php

namespace App\Exports;

use App\Models\Absen;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithDrawings;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;

class AbsenExport implements FromCollection, WithHeadings, WithMapping, WithDrawings
{
    protected $range;
    protected $userId;
    protected $data;

    public function __construct($range = 'minggu', $userId = null)
    {
        $this->range = $range;
        $this->userId = $userId;
    }

    public function collection()
    {
        $query = Absen::with('user');

        if ($this->range === 'minggu') {
            $query->where('tanggal', '>=', now()->subWeek());
        } elseif ($this->range === 'bulan') {
            $query->where('tanggal', '>=', now()->subMonth());
        } elseif ($this->range === 'tahun') {
            $query->where('tanggal', '>=', now()->subYear());
        }

        if ($this->userId) {
            $query->where('user_id', $this->userId);
        }

        $this->data = $query->get();
        return $this->data;
    }

    public function map($absen): array
    {
        return [
            $absen->user->nama ?? '-',
            $absen->tanggal,
            $absen->jam_masuk,
            $absen->jam_pulang,
            $absen->status,
            '',
            '',
            $absen->lat_masuk,
            $absen->lon_masuk,
            $absen->lat_pulang,
            $absen->lon_pulang,
        ];
    }

    public function headings(): array
    {
        return [
            'Nama',
            'Tanggal',
            'Jam Masuk',
            'Jam Pulang',
            'Status',
            'Foto Masuk',
            'Foto Pulang',
            'Latitude Masuk',
            'Longitude Masuk',
            'Latitude Pulang',
            'Longitude Pulang'
        ];
    }

    public function drawings()
    {
        $drawings = [];

        foreach ($this->data as $index => $absen) {
            $rowNumber = $index + 2;
            if ($absen->foto_masuk && file_exists(public_path($absen->foto_masuk))) {
                $drawing = new Drawing();
                $drawing->setPath(public_path($absen->foto_masuk));
                $drawing->setHeight(50);
                $drawing->setCoordinates('F' . $rowNumber);
                $drawings[] = $drawing;
            }

            // Foto Pulang
            if ($absen->foto_pulang && file_exists(public_path($absen->foto_pulang))) {
                $drawing = new Drawing();
                $drawing->setPath(public_path($absen->foto_pulang));
                $drawing->setHeight(50);
                $drawing->setCoordinates('G' . $rowNumber);
                $drawings[] = $drawing;
            }
        }

        return $drawings;
    }
}
