<?php

namespace App\Http\Controllers;

use App\Models\Pengajuan;
use App\Models\Absen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class PengajuanController extends Controller
{
    public function index()
    {
        if (Auth::user()->role === 'HR') {
            $pengajuans = Pengajuan::with('user')->latest()->get();
        } else {
            $pengajuans = Pengajuan::where('user_id', Auth::id())->latest()->get();
        }

        return response()->json($pengajuans);
    }

    public function addPengajuan(Request $request)
    {
        try {
            $request->validate([
                'jenis' => 'required|in:cuti,izin,sakit',
                'tanggal_mulai' => 'required|date',
                'tanggal_selesai' => 'required|date|after_or_equal:tanggal_mulai',
                'alasan' => 'nullable|string',
                'bukti' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:2048'
            ]);

            $pathBukti = null;
            if ($request->hasFile('bukti')) {
                $pathBukti = $request->file('bukti')->store('bukti_pengajuan', 'public');
            }

            $pengajuan = Pengajuan::create([
                'user_id' => Auth::id(),
                'jenis' => $request->jenis,
                'tanggal_mulai' => $request->tanggal_mulai,
                'tanggal_selesai' => $request->tanggal_selesai,
                'alasan' => $request->alasan,
                'bukti' => $pathBukti,
                'status' => 'menunggu'
            ]);
            return back()->with('pengajuans_success', "Pengajuan diproses");
        } catch (\Exception $e) {
            return back()->with('pengajuans_fail', $e->getMessage());
        }
    }

    public function approve($id)
    {
        $pengajuan = Pengajuan::findOrFail($id);

        if ($pengajuan->status !== 'menunggu') {
            return response()->json(['message' => 'Pengajuan sudah diproses.'], 400);
        }

        $pengajuan->status = 'disetujui';
        $pengajuan->save();

        $mulai = Carbon::parse($pengajuan->tanggal_mulai);
        $selesai = Carbon::parse($pengajuan->tanggal_selesai);
        for ($tanggal = $mulai->copy(); $tanggal->lte($selesai); $tanggal->addDay()) {
            Absen::updateOrCreate(
                ['user_id' => $pengajuan->user_id, 'tanggal' => $tanggal->format('Y-m-d')],
                ['status' => $pengajuan->jenis]
            );
        }

        return response()->json(['message' => 'Pengajuan disetujui dan absensi diperbarui']);
    }
    public function reject($id)
    {
        $pengajuan = Pengajuan::findOrFail($id);

        if ($pengajuan->status !== 'menunggu') {
            return response()->json(['message' => 'Pengajuan sudah diproses.'], 400);
        }
        $pengajuan->status = 'ditolak';
        $pengajuan->save();
        return response()->json(['message' => 'Pengajuan ditolak']);
    }
}
