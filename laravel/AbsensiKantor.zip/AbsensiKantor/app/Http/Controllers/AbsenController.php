<?php

namespace App\Http\Controllers;

use App\Models\Absen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use App\Exports\AbsenExport;
use Maatwebsite\Excel\Facades\Excel;

class AbsenController extends Controller
{



    const LAT_KANTOR =  -6.186596;
    const LON_KANTOR = 106.691781;
    const MAX_DISTANCE_KM = 1;
    const JAM_KERJA = '09:00';
    const TOLERANSI_MENIT = 10;
    const JAM_PULANG = '01:00';

    public function absen(Request $request)
    {
        $request->validate([
            'lat'  => 'required|numeric',
            'lon'  => 'required|numeric',
            'foto' => 'required|string',
            'type' => 'required|in:masuk,pulang',
        ]);

        $userId = Auth::id();
        $tanggal = Carbon::now()->toDateString();
        $waktu   = Carbon::now();
        $jarak = $this->hitungJarak($request->lat, $request->lon, self::LAT_KANTOR, self::LON_KANTOR);
        if ($jarak > self::MAX_DISTANCE_KM) {
            return response()->json(['message' => 'Anda berada di luar jangkauan absensi!'], 422);
        }

        $filename = $request->type . '_' . uniqid() . '.png';
        $decodedImage = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $request->foto));
        Storage::disk('public')->put("absensi/{$filename}", $decodedImage);
        $fotoPath = "storage/absensi/{$filename}";

        $absen = Absen::firstOrNew([
            'user_id' => $userId,
            'tanggal' => $tanggal,
        ]);

        if ($request->type === 'masuk') {
            if ($absen->jam_masuk) {
                return response()->json(['message' => 'Anda sudah absen masuk hari ini.'], 422);
            }
            $jamKerja = Carbon::parse(self::JAM_KERJA);
            $isTerlambat = $waktu->greaterThan($jamKerja->addMinutes(self::TOLERANSI_MENIT));
            $absen->jam_masuk = $waktu->format('H:i:s');
            $absen->lat_masuk = $request->lat;
            $absen->lon_masuk = $request->lon;
            $absen->foto_masuk = $fotoPath;
            $absen->terlambat = $isTerlambat;
            $absen->status = 'hadir';
        }
        if ($request->type === 'pulang') {
            if ($absen->jam_pulang) {
                return response()->json(['message' => 'Anda sudah absen pulang hari ini.'], 422);
            }
            $jamPulangMinimal = Carbon::parse(self::JAM_PULANG);
            if ($waktu->lt($jamPulangMinimal)) {
                return response()->json([
                    'message' => 'Absen pulang hanya bisa dilakukan setelah jam 16:00.',
                ], 422);
            }

            $absen->jam_pulang = $waktu->format('H:i:s');
            $absen->lat_pulang = $request->lat;
            $absen->lon_pulang = $request->lon;
            $absen->foto_pulang = $fotoPath;

            if (!$absen->jam_masuk) {
                $absen->status = 'alpa';
            }
        }

        $absen->save();
        return response()->json([
            'message' => "Absen {$request->type} berhasil",
        ]);
    }
    private function hitungJarak($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371;
        $latFrom = deg2rad($lat1);
        $lonFrom = deg2rad($lon1);
        $latTo = deg2rad($lat2);
        $lonTo = deg2rad($lon2);

        $latDelta = $latTo - $latFrom;
        $lonDelta = $lonTo - $lonFrom;

        $angle = 2 * asin(sqrt(
            pow(sin($latDelta / 2), 2) +
                cos($latFrom) * cos($latTo) *
                pow(sin($lonDelta / 2), 2)
        ));

        return $earthRadius * $angle;
    }

    public function export(Request $request)
    {
        $range = $request->input('range', 'minggu');
        $userId = $request->input('user_id');

        return Excel::download(new AbsenExport($range, $userId), 'rekap-absen.xlsx');
    }
}
